from flask import Flask, request
from twilio.twiml.messaging_response import MessagingResponse
from twilio.rest import Client
import requests
from googletrans import Translator
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
import os

app = Flask(__name__)

# Environment variables (set these in Render)
TWILIO_ACCOUNT_SID = os.environ.get('TWILIO_ACCOUNT_SID')
TWILIO_AUTH_TOKEN = os.environ.get('TWILIO_AUTH_TOKEN')
TWILIO_PHONE_NUMBER = os.environ.get('TWILIO_PHONE_NUMBER')  # 'whatsapp:+14155238886' for sandbox
OPENWEATHER_API_KEY = os.environ.get('OPENWEATHER_API_KEY')

client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
translator = Translator()

# List of users to send daily updates (must opt-in on Twilio sandbox first)
users = {
    "Pune": ["whatsapp:+91XXXXXXXXXX"],
    "Mumbai": ["whatsapp:+91YYYYYYYYYY"]
}

def get_weather_data(city_name):
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city_name}&appid={OPENWEATHER_API_KEY}&units=metric&lang=en"
    response = requests.get(url)
    if response.status_code != 200:
        return None
    data = response.json()
    weather = data['weather'][0]['description']
    temp = data['main']['temp']
    return f"Today in {city_name}, it is {weather} with a temperature of {temp}°C."

def translate_to_marathi(text):
    try:
        translated = translator.translate(text, dest='mr')
        return translated.text
    except:
        return "अनुवाद करण्यात अडचण आली."

def send_daily_updates():
    for city, numbers in users.items():
        weather_info = get_weather_data(city)
        if weather_info:
            message = translate_to_marathi(weather_info)
            for number in numbers:
                client.messages.create(
                    body=message,
                    from_=TWILIO_PHONE_NUMBER,
                    to=number
                )
        else:
            print(f"Couldn't get weather for {city}")

@app.route("/whatsapp", methods=['POST'])
def whatsapp_reply():
    incoming_msg = request.values.get('Body', '').strip()
    resp = MessagingResponse()
    msg = resp.message()

    if not incoming_msg:
        msg.body("कृपया शहराचे नाव पाठवा.")
        return str(resp)
    
    city = incoming_msg
    weather_info = get_weather_data(city)

    if weather_info:
        marathi_response = translate_to_marathi(weather_info)
        msg.body(marathi_response)
    else:
        msg.body("क्षमस्व, हवामान माहिती मिळवता आली नाही.")
    
    return str(resp)

# Schedule daily messages at 7:30 AM IST
scheduler = BackgroundScheduler(timezone="Asia/Kolkata")
scheduler.add_job(send_daily_updates, 'cron', hour=7, minute=30)
scheduler.start()

if __name__ == "__main__":
    app.run(debug=True)
